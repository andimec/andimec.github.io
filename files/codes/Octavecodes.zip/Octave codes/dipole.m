%Open de Software
openfemm;

% We need to create a new Magnetostatics document to work on.
newdocument(0);

% Define the problem type.  Magnetostatic; Units of mm; Axisymmetric; 
% Precision of 10^(-8) for the linear solver; a placeholder of 0 for 
% the depth dimension, and an angle constraint of 30 degrees

mi_probdef(0, 'millimeters', 'planar', 1.e-8, l_yoke, 30);

%External border
vector_1=       [0,0;
                 0,h;
                 0,h+h_tooth+w_leg_h;
                 0,h+h_tooth+w_leg_h+y_margin;
                 w+x_incre+x_coil+w_leg_v+x_margin,h+h_tooth+w_leg_h+y_margin;
                 w+x_incre+x_coil+w_leg_v+x_margin,0;
                 w+x_incre+x_coil+w_leg_v,0;
                 w+x_incre+x_coil,0
                 0,0];
mi_drawpolyline(vector_1);

%Border internal of the yoke
vector_2=       [0,h;
                 w-w_perc,h;
                 w-w_perc+x_incli,h-h_perc;
                 w-x_incli-radius_tooth,h-h_perc;
                 w,h-h_perc+radius_tooth;
                 w+x_incre,h+h_tooth;
                 w+x_incre+x_coil,h+h_tooth;
                 w+x_incre+x_coil,0];
mi_drawpolyline(vector_2(1:4,:));
mi_drawarc(vector_2(4,1),vector_2(4,2),vector_2(5,1),vector_2(5,2),90,1);
mi_drawpolyline(vector_2(5:end,:));

%Border external of the yoke
vector_3=        [0,h+h_tooth+w_leg_h;
                 w+x_incre+x_coil+w_leg_v-x_cut,h+h_tooth+w_leg_h;
                 w+x_incre+x_coil+w_leg_v,h+h_tooth+w_leg_h-x_cut;
                 w+x_incre+x_coil+w_leg_v,0];
     
mi_drawpolyline(vector_3(1:2,:));
mi_drawarc(vector_3(3,1),vector_3(3,2),vector_3(2,1),vector_3(2,2),90,1)
mi_drawpolyline(vector_3(3:4,:));
                 
%Coil
mi_drawrectangle(w+x_incre+sep_coil,h+h_tooth-sep_coil,w+x_incre+sep_coil+width_coil,h+h_tooth-sep_coil-height_coil)

%Add labels
mi_addblocklabel(w/2,h+h_tooth/2); %Iron
mi_addblocklabel(w+x_incre+sep_coil+width_coil/2,h+h_tooth/2); %Cupper
mi_addblocklabel(w/2,h/2); %Air
mi_addblocklabel(w+x_incre+x_coil+w_leg_v+x_margin/2,h+h_tooth+w_leg_h+y_margin/2); %Air


%Add materials
%mi_addmaterial('Air', 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0);
mi_getmaterial("Air");
mi_getmaterial("Copper");
mi_getmaterial("Cold rolled low carbon strip steel");
mi_modifymaterial("Cold rolled low carbon strip steel",6,1);
mi_modifymaterial("Cold rolled low carbon strip steel",8,0.98);

% Add a "circuit property" so that we can calculate the properties of the
% coil as seen from the terminals. 
%mi_addcircprop(�circuitname�, current, circuittype (0->paralel,1->serie))
A_virt=coilWidth*coilHeight;
%I_virtual=I_magnet*A_virt/A_net_total;
mi_addcircprop('icoil', I_magnet, 1);

%Set labels
mi_selectlabel(w/2,h+h_tooth/2);
mi_setblockprop("Cold rolled low carbon strip steel", 0, 2, '<None>', 0, 0, 0);
mi_clearselected

mi_selectlabel(w+x_incre+sep_coil+width_coil/2,h+h_tooth/2);
mi_setblockprop("Copper", 0, 2, 'icoil', 0, 0, N_int); %Number of turns
mi_clearselected

mi_selectlabel(w/2,h/2);
mi_setblockprop('Air', 0, 2, '<None>', 0, 0, 0);
mi_clearselected

mi_selectlabel(w+x_incre+x_coil+w_leg_v+x_margin/2,h+h_tooth+w_leg_h+y_margin/2);
mi_setblockprop('Air', 0, 10, '<None>', 0, 0, 0);
mi_clearselected

mi_zoomnatural


mi_addboundprop("Dirichlet", 0, 0, 0, 0, 0, 0, 0, 0, 0);

mi_selectsegment(0,h/2);
mi_setsegmentprop("Dirichlet",0, 1,0,0,0);
mi_clearselected

mi_selectsegment(0,h+h_tooth);
mi_setsegmentprop("Dirichlet",0, 1,0,0,0);
mi_clearselected

mi_selectsegment(0,h+h_tooth+w_leg_h+y_margin/2);
mi_setsegmentprop("Dirichlet",0, 1,0,0,0);
mi_clearselected

mi_selectsegment(w,h+h_tooth+w_leg_h+y_margin);
mi_setsegmentprop("Dirichlet",0, 1,0,0,0);
mi_clearselected

mi_selectsegment(w+x_incre+x_coil+w_leg_v+x_margin,h);
mi_setsegmentprop("Dirichlet",0, 1,0,0,0);
mi_clearselected

mi_saveas("opti_yoke.fem");