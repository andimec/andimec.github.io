function F_obj = yoke_optimi(X)
% --- X values ---
%	1) a=18:43;
%	2) %altura= ;
%	3) %ancho= ;
%	4) X_incre= ;
%	5) Current= ; max
%	6) W_leg_perc 
% 7) x_cut_perc

%length in mm 


%sqProfile = 12; %edimension of the conductor
cond_height = 11;
cond_breadth = 11;
coolingBoreDiam = 6;
coolingBoreRadius = coolingBoreDiam/2; %9e-3/2, 

gfrV = 23;
gfrH = 20;
vacuumChamberThickness = 2;
tolerance = 0.5;
insulation = 0.5;
    
%Compute Aperture
h_gap = 2* gfrV + 2* vacuumChamberThickness + 2* tolerance + 2* insulation
deltaB_B = 1e-3;

%Computation of mangentic length
k = 0.55; %given
l_iron = 340; %Max: 340mm -> Test different values %This is also the yoke thickness
l_mag = l_iron + 2*h_gap*k
fprintf('Magnetic length is %3.2f mm\n', l_mag)


%Compute Sagitta
alpha = 36*pi/180;
rM = (l_mag/2)/sin(alpha/2) %magnet bending radius
s = rM*(1-cos(alpha/2));
fprintf('Sagitta is %3.2f mm\n', s)

%Compute enlarged gfrH
gfrH_enlarged = gfrH + s;
fprintf('Enlarged horizontal gfr is %3.2f mm\n', gfrH_enlarged)

%Compute Flux Density
T = 12* 7 * 1e6;
E0 = 12 *938 *1e6;
q = 6;
c = 3e8;

B =  1/(q*c*rM*1e-3) * sqrt(T^2+2*T*E0)
fprintf('B is %3.2f T\n', B)

%% Compute pole width
a_unopt = (-0.36*log(deltaB_B) - 0.9)/2*h_gap %pole overhang, unoptimized
a_opt = (-0.14 * log(deltaB_B)-0.25)/2*h_gap   %pole overhang, optimized
%a = 35; %taking a as 25 mm %<-------------------------------------to optimized
a = X(1);
marg_p = 0.0*1;
marg_m=-marg_p;
w_p = 2*a + 2* gfrH_enlarged + 2*marg_p
%w_m = 2*a + 2* gfrH_enlarged + 2*marg_m;
%fprintf('%1.2f mm < w < %1.2f mm\n', w_m*1e3, w_p*1e3)
yoke_width = w_p %use max value for further design

%% Compute Ampere turns
mu0 = 4*pi*1e-7;
NI = (B*h_gap*1e-3)/(2*mu0)

I_max = 600*0.9; %margin 0.1
N = NI/I_max
N_int = 54;
fprintf('Round N = %1.2f to %i turns\n', N, N_int)
%I_magnet = NI/N_int; %<-------------------------------------to optimized
I_magnet  = X(5);

fprintf('I_max = %1.2f A, I_magnet = %1.2f A \n', I_max, I_magnet)
if I_magnet <= I_max
    disp('Current in magnet conforms margin.')
else 
    disp('Current in magnet does not conforms margin.')
end

%% Compute dimensions of coil
coilInsulation = 0.5;
groundInsulation = 1.5;

noVert = 6; 
noHorz = 9;

coilWidth = noHorz * (cond_breadth + 2*coilInsulation) + 2*groundInsulation
coilHeight = noVert * (cond_height + 2*coilInsulation) + 2*groundInsulation
fprintf('Dimension of coil: Width = %1.2f mm, Height = %1.2f mm\n', coilWidth, coilHeight);

%%
R_edge = 1;

A_bores = pi * coolingBoreRadius^2
A_radius = R_edge^2 - pi*R_edge^2/4;
A_square = cond_breadth * cond_height;

A_net_coil = A_square - 4*A_radius - A_bores
A_net_total = A_net_coil*noVert*noHorz
fprintf('Net cross section per coil: %1.2f mm^2 and total: %1.2f mm^2 \n', A_net_coil, A_net_total)

%current density
j = I_magnet/A_net_coil 

m=2; %no coils per magnet
l_iron_gap = 4; % 5mm on each side
w_gap = 4;      % 5mm on each side

% coil length
l_avg_turn = 2*(l_iron + l_iron_gap + yoke_width + w_gap) + 4 * coilWidth
l_avg = noHorz*noVert * l_avg_turn

% coil resistance R
rho_Cu = 1.68 * 1e-8;
R =  l_avg * 1e-3 / (A_net_coil * 1e-6) * rho_Cu

% dc voltage V
V = I_magnet * m * R

% dissipated power P
%P = rho_Cu * B*h/mu0*j*l_avg_turn *1e6
P_loss = V*I_magnet %this is the power loss in one magnet (2 coils)

%so power loss in one coil is
P_loss_unitcoil = P_loss/2

%% Cooling
dT_max = 15 %degC;
Kc = 1; %no of coils
Kw = 1; %no of cooling circuits per coil

d = coolingBoreDiam %hydraulic diameter
Q = 14.3 * P_loss_unitcoil/dT_max * 1e-3 %coolant flow in L/min
u_avg = 66.67 * Q/(pi*d^2) %average water velocity in m/s


l_cooling = Kc * l_avg / Kw * 1e-3 %in meter

dp = 60 * l_cooling * (Q^1.75/d^4.75)   %pressure drop in bars

nu = 6.58*1e-7;  %
Re = d * u_avg/nu * 1e-3 % >4000 so it is in turbulent range

B_leg = 1.5;

W_leg = B*(yoke_width+2*h_gap)/B_leg/2;

%W_leg_perc = 0.85;% <--------------------------------------------Optimizar
W_leg_perc = X(6);

%parameter to optimization
l_yoke=l_iron;
w_leg_v=W_leg*W_leg_perc;
w_leg_h=w_leg_v;
h=h_gap/2;
w=yoke_width/2;

%x_incre=0; %<--------------------------------------------Optimizar
x_incre = X(4);
sep_coil=4;
width_coil=coilWidth;
height_coil=coilHeight;
x_coil=width_coil+sep_coil*2;
h_tooth=height_coil+sep_coil*2;
x_margin=50;
y_margin=50;
%perc_tooth_w=0.3;%<--------------------------------------------Optimizar
%perc_tooth_h=0.0;%<--------------------------------------------Optimizar

perc_tooth_w=X(3);
perc_tooth_h=X(2);
w_perc=perc_tooth_w*w;
h_perc=perc_tooth_h*h;
x_incli=0.1;
%x_cut_perc=0.6; %<--------------------------------------------Optimizar
x_cut_perc=X(7);
x_cut=x_cut_perc*w_leg_v;

%	2) %altura= %h ;
%	3) %ancho= %w;
%	4) X_incre= ;
%	5) Current= ; max
%	6) W_leg_perc 
% 7) x_cut_perc

dipole;

%Postprocesing
% Now,analyze the problem and load the solution when the analysis is finished
mi_analyze
mi_loadsolution

% Or we could, for example, plot the results along a line using 
% Octave's built-in plotting routines:

x1_plot=0:1:w;
y1_plot=zeros(1,length(x1_plot));
bee=abs(mo_getb(x1_plot,y1_plot));
target1=bee(:,2).-B;
plot(x1_plot, target1);
avrB=mean(bee(:,2));

y2_plot = linspace(h+h_tooth+2,h+h_tooth+w_leg_h-2,20);
x2_plot = (w+x_incre+x_coil/2)*ones(1,length(y2_plot));
bee_leg=abs(mo_getb(x2_plot,y2_plot));
target2=B_leg-abs(bee_leg(:,1));
figure(2)
plot(y2_plot, target2);

y3_plot = linspace(h+h_tooth+2,h+h_tooth+w_leg_h-x_cut/2-2,20);
x3_plot = linspace(w+x_incre+x_coil+2,w+x_incre+x_coil+w_leg_v-x_cut/2-2,20);
bee_leg_cut=abs(mo_getb(x3_plot,y3_plot));
target3=B_leg-abs(norm(bee_leg_cut(1,:)));
%figure(3)
%plot(1:20, target3);

x4_plot=linspace(0,w,20);
y4_plot=h*ones(1,20);
bee4=abs(mo_getb(x4_plot,y4_plot));
for i=1:18 %no tomo los extremos
target4(i)=norm(bee4(i,:));
end
target4=target4.-B_leg;

%mass estimation
mo_selectblock(w/2,h+h_tooth/2)
vol_steel=mo_blockintegral(10)*4; %10: volumen m^3
mo_clearblock

mo_selectblock(w+x_incre+sep_coil+width_coil/2,h+h_tooth/2)
vol_coil=mo_blockintegral(5)*l_avg_turn*10^-3*2; %5: area m^3
mo_clearblock
density_copper=8941;
density_steel=7.8;

mass_copper=density_copper*vol_coil;
mass_steel=density_steel*vol_steel;

%Costs
cost_dipole

F_obj= mean(target1)^4+mean(target2)^4+P_Total+mean(target3)^4+mean(target4)^2;
end