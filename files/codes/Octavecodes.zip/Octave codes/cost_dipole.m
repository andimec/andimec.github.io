%Add constant:
% mass_steel
% mass_coil
% n_dipole
% P_loss

%Fix
P_Design=10000;% �
P_Stamping_tool=15000;% �
P_Stacking_tool=12000;% �
P_Winding_tool=10000;% �
P_Impregnation_mould= 20000; %�

P_fix=P_Design+P_Stacking_tool+P_Stamping_tool+P_Winding_tool+P_Impregnation_mould;

% Cost for material & manufacturing
P_Steel= 2;% �/kg
P_Copper_conductor= 22;% �/kg
P_Yoke_manufacturing= 12;% �/kg
P_Coil_manufacturing= 36;% �/kg
auxilliarycost=5000; %in euros
%Cost for n_dipoles + 1 extra dipole = 4 dipoles
P_manuf=(n_dipole+1)*((P_Steel+P_Yoke_manufacturing)*mass_steel+(P_Copper_conductor+P_Coil_manufacturing)*mass_copper+auxilliarycost);

% Cost for running
years=20;

workinghours=4200*years; %in hours 
powerofamagnet=P_loss; %in Watt
consumption=workinghours*powerofamagnet/1e6; % in MWh
pricemwwh=125; %in euros/MWh
priceoffunctioning=consumption*pricemwwh;  % in euros 
P_costonemagnet=priceoffunctioning; % in euros 

%costbeforeuse=4*(costcopper+coststeel)+costfortoolsanddesign; % for 4 magnets in euros 
%printf('We say that we make 4 magnets, so the cost for the design, the materials and the manufacturing is %1.2f euros\n', costbeforeuse);
P_costofrunningmagnets=n_dipole*P_costonemagnet; % only 3 magnets are working, other is a spare one

%totalcost=(costbeforeuse+costofrunningmagnets)/1e3; %total price in kilo euros 
inflation=0.05;
P_costofrunningmagnets_future=P_costofrunningmagnets*(1-inflation)^(years);

printf('Cost of design %1.2f euros\n', P_fix);
printf('Cost of manufacturing 4 magnet %1.2f euros\n', P_manuf);
printf('The cost for 3 magnets functionning during 20 years is %1.2f euros \n', P_costofrunningmagnets_future);

P_Total=P_manuf+P_fix+P_costofrunningmagnets_future;
P_Total_keuro = P_Total/10^3;

printf('The total estimated cost is %1.2f kilo euros\n', P_Total_keuro);
