clear all, close all, clc
pkg load optim

%	1) a=18:43;
%	2) %altura= ;
%	3) %ancho= ;
%	4) X_incre= ;
%	5) Current= ; max
%	6) W_leg_perc 
% 7) x_cut_perc

x0=[ 35; 0.00; 0.03; 0.0;530; 0.85; 0.6];
lb=[ 18; 0.00; 0.00; 0.0;400; 0.70; 0.2];
ub=[ 43; 0.01; 0.03; 10; 540; 1.00; 0.6];
Aeq = [];
beq = [];
A = [];
b = [];

[w_min values] = fmincon(@yoke_optimi,x0,A,b,Aeq,beq,lb,ub);